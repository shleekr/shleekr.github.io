#!/bin/bash
sed -e 's/ /<space>/g' -e 's/@0@/<epsilon>/g' korinvert.fomaatt > korinvert.att

(export LANG=C; awk -F'\t' ' { if (NF == 4) { print $3 ; print $4 ; } } ' korinvert.att | sort | uniq | awk ' BEGIN { printf("<epsilon>    0\n") ; cnt = 1 ; } { if ($1 != "<epsilon>") { printf("%s       %d\n",$1,cnt) ; cnt++ ; } } ' > korinvert.sym ;)

fstcompile --isymbols=korinvert.sym --osymbols=worduniprob.sym korinvert.att > korinvertuni.att
fstcompile --isymbols=worduniprob.sym --osymbols=worduniprob.sym worduniprob.att > worduniprob.cmp
fstdeterminize worduniprob.cmp worduniprob.det
fstminimize worduniprob.det worduniprob.min
fstarcsort worduniprob.min worduniprob.srt
mv korinvertuni.att korinvertuni.fst
fstcompose korinvertuni.fst worduniprob.srt > korfinaluni.fst

