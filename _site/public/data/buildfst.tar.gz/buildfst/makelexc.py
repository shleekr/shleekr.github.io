#!/usr/bin/env python
#-*- coding: utf-8 -*-

"""
   MakeLexc : Make Lexc file from tagged corpus

   Programmed by Sangho Lee
"""

import sys, getopt, codecs, re, esm
reload (sys)
sys.setdefaultencoding('utf-8')


lexcHeader = """\
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!                                                  !!
!! 한국어 형태소 분석                               !!
!!                                                  !!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!! 한국어 형태소 품사 리스트 정의 !!!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! 부사   : /ac /ad /ai /am 
! 관형사 : /di /dm /dn /du
! 어미   : /ec /ed /ef /en /ep /ex
! 감탄사 : /it
! 체언   : /na /nc /nd /ni /nm /nn /np /nr /ns /nu /nb
! 조사   : /pa /pc /pd /po /pp /ps /pt /pv /px /pq
! 용언   : /vb /vi /vj /vx
! 접사   : /xa /xj /xn /xv
! 심벌   : /sc /se /sl /sr /sd /su /sy /so
!
! 추정   : gs+ (Guesser)
! 한자   : /nh (체언이면서 한자)
!
! 불규칙 : /irrL /irrb /irrd /irrh /irrl /irrs /irru
!
! /irrL  : '러' 불규칙 : 이르다, 누르다, 푸르다
! /irrb  : 'ㅂ' 불규칙
! /irrd  : 'ㄷ' 불규칙
! /irrh  : 'ㅎ' 불규칙
! /irrl  : '르' 불규칙 : 가르다, 고르다, 구르다, 기르다
! /irrs  : 'ㅅ' 불규칙
! /irru  : '우' 불규칙 : 푸다

Multichar_Symbols   /ac /ad /ai /am         ! 부사
                    /di /dm /dn /du         ! 관형사
                    /ec /ed /ef /en /ep /ex ! 어미
                    /it                     ! 감탄사
                    /na /nc /nd /ni /nm /nn /np /nr /ns /nu /nb ! 체언
                    /pa /pc /pd /po /pp /ps /pt /pv /px /pq /pm ! 조사
                    /vb /vi /vj /vx /vn     ! 용언
                    /xa /xj /xn /xv         ! 접사
                    /sc /se /sf /sl /sr /sd /su /sy /so ! 심벌
                    /nh /ne /un ! 한자 (cHinese, English)
                    /irrL /irrb /irrd /irrh /irrl /irrs /irru ! 불규칙 코드표
                    %_ㄴ %_ㄹ %_ㅁ %_ㅂ %_ㅅ %_ㅇ ! 종성으로 시작 (어미, 조사)

Definitions
        Digit       = %0|1|2|3|4|5|6|7|8|9 ;
        Alphabet    = a|b|c|d|e|f|g|h|i|j|k|l|m|n|o|p|q|r|s|t|u|v|w|x|y|z|
                      A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P|Q|R|S|T|U|V|W|X|Y|Z ;
        Hanja       = 
"""

basictags = [ 'ac', 'ad', 'ai', 'am', # 부사
              'di', 'dm', 'dn', 'du', # 관형사
              'ec', 'ed', 'ef', 'en', 'ep', 'ex', # 어미
              'it',                   # 감탄사
              'na', 'nc', 'nd', 'ni', 'nm', 'nn', 'np', 'nr', 'ns', 'nu', 'nb', # 체언
              'pa', 'pc', 'pd', 'po', 'pp', 'ps', 'pt', 'pv', 'px', 'pq', 'pm', # 조사
              'vb', 'vi', 'vj', 'vx', 'vn', # 용언
              'xa', 'xj', 'xn', 'xv',       # 접사
              'sc', 'se', 'sf', 'sl', 'sr', 'sd', 'su', 'sy', 'so', # 심벌
              'nh', 'ne', 'un' ] # 한자 (cHinese, English)

tagnames = { 'ac' : '접속부사'  , 'ad' : '부사', 'ai' : '의문부사', 'am' : '지시부사',
        'di' : '의문관형사', 'dm' : '지시관형사', 'dn' : '관형사', 'du' : '수관형사',
        'ec' : '연결어미', 'ed' : '관형사형전성어미', 'ef' : '어말어미', 
        'en' : '명사형전성어미', 'ep' : '선어말어미', 'ex' : '보조적연결어미',
        'it' : '감탄사',
        'na' : '동작성보통명사', 'nc' : '보통명사', 'nd' : '의존명사', 
        'ni' : '의문대명사', 'nm' : '지시대명사',
        'nn' : '수사', 'np' : '인칭대명사', 'nr' : '고유명사', 'ns' : '상태성보통명사',
        'nu' : '단위성의존명사', 'nb' : '숫자',
        'pa' : '부사격조사', 'pc' : '접속조사', 'pd' : '관형격조사', 'po' : '목적격조사',
        'pp' : '서술격조사', 'ps' : '주격조사', 'pt' : '주제격조사', 'pv' : '호격조사',
        'px' : '보조사', 'pq' : '인용격조사', 'pm' : '보격조사',
        'vb' : '동사', 'vi' : '의문형용사', 'vj' : '형용사', 'vx' : '보조용언', 'vn' : '부정지정사',
        'xa' : '부사파생접미사', 'xj' : '형용사파생접미사', 'xn' : '명사접미사',
        'xv' : '동사파생접미사',
        'sc' : '쉼표', 'se' : '줄임표', 'sf' : '마침표', 'sl': '여는따옴표', 'sr' : '닫는따옴표',
        'sd' : '이음표', 'su' : '단위', 'sy' : '화폐단위', 'so' : '기타기호',
        'nh' : '한자', 'ne' : '영어', 'un' : '분석불가' }


particles = ('pa', 'pc', 'pd', 'po', 'ps', 'pt', 'pv', 'px', 'pq', 'pm') # excluding 'pp'
endings   = ('ec', 'ed', 'ef', 'ex') # excluding 'en', 'ep'

specialchar = "!\"#$%&'()*+,-.0:;<=>?@[\\]^|/_`{}~"

excludechar = "갋궃궿긘긦긩깣껩꾁꿏꿕뀫냊녓놰뇍뇡눛늫됑됬둏뒴딲뗳똠뜄뜌뜽띡띧럅럯렜롴릔맳맻" \
              "멫묌믛믜믠믯믱뱟뱡볓뵝붔붝붭붴븥븨븩븰븽뻿뽃뽓뿕뿠샆섥솂솓쇡쇵슌슫슳싀싖싿쌋" \
              "쌰썪쎕쎗쎠쏼쒠옿웂읃읎읪젂젋죅즁쩰쫒쬧쬬쯕찟찣찿츅캿켙퀙툅팦퍤픙픵햝헡헸훍훛흝"

disallows = { 'ec'  : [ 'xj', 'xn', 'en', 'ef', 'ed', 'ep', 'xv', 'np', 'nd', 'vb', 'nr', 'nc', 'ad', 'it', 'pp', 'dn', 'nn', 'fi', 'nm' ],
              'ed'  : [ 'vx', 'vb', 'ed', 'ef', 'ec', 'ex', 'ec', 'en', 'ep', 'xa', 'vj', 'ad', 'xn' ],
              'ef'  : [ 'pp', 'en', 'vb', 'xn', 'ef', 'ed', 'vx', 'nc', 'xv', 'ec', 'ad', 'it' ],
              'en'  : [ 'vj', 'nd', 'vn', 'vb', 'ef', 'xv', 'xj', 'ec', 'ed', 'vx', 'ep', 'ex', 'nr', 'pv', 'ec' ],
              'ep'  : [ 'sl', 'sv', 'fi', 'sr', 'pt', 'nc', 'xn', 'px', 'se', 'sd', 'nr', 'pp', 'px', 'sf', 'sc' ],
              'ex'  : [ ],
              'na'  : [ 'vb', 'vi', 'vj', 'vx', 'vn', 'ec', 'ed', 'ef', 'en', 'ep', 'ex' ],
              'nc'  : [ 'ad', 'du', 'ec', 'ed', 'ec', 'en', 'ep', 'du', 'ef', 'vx', 'dm', 'ex', 'ni', 'ac', 'di', 'vb'],
              'nd'  : [ 'du', 'ad', 'na', 'ns', 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'vb', 'vx' ],
              'ni'  : [ 'ad', 'ec', 'ed', 'ef', 'en', 'ep', 'ex' ],
              'nm'  : [ 'ad', 'du', 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'vb' ],
              'nn'  : [ 'dn', 'ad', 'di', 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'vb' ],
              'np'  : [ 'ad', 'ac', 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'vb' ],
              'nr'  : [ 'ad', 'dn', 'ac', 'du', 'dm', 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'vb', 'vj', 'vx', 'xv', 'xj', 'nn', 'nd' ],
              'ns'  : [ 'ec', 'ed', 'ef', 'en', 'ep', 'ex' ],
              'nu'  : [ 'vx', 'ad', 'dn', 'ec', 'ed', 'ef', 'en', 'ep', 'ex' ],
              'nb'  : [ 'vx', 'ec', 'ed', 'ef', 'en', 'ep', 'ex' ],
              'ai'  : [ 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'xj', 'xv' ],
              'ad'  : [ 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'xj', 'xv', 'nc', 'nd', 'xn', 'vb', 'ad' ],
              'ac'  : [ 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'xj', 'xv' ],
              'am'  : [ 'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'xj', 'xv' ],
              'di'  : [ 'ec', 'dm', 'dn', 'du', 'xj', 'vb', 'vj', 'xv' ],
              'dm'  : [ 'ec', 'di', 'dn', 'du', 'xj', 'vb', 'vj', 'xv', 'vx' ],
              'dn'  : [ 'di', 'dm', 'xj', 'vb', 'vj', 'xv', 'xj' ],
              'du'  : [ 'ef', 'xj', 'vb', 'vj', 'xv', 'ad' ],
              'pa'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pc'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pd'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'po'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'ps'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pt'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pv'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'px'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pq'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pm'  : [ 'vj', 'vx', 'nc', 'vb', 'ed', 'na', 'xn', 'ad', 'nd', 'nr', 'ec', 'xj', 'xv', 'dn', 'ns', 'du', 'ef', 'np' ],
              'pp'  : [ 'ps', 'vb', 'xa', 'pq', 'px', 'pp', 'po', 'nd', 'nc', 'ni', 'sr', 'sl', 'sc', 'sf', 'nr', 'pc', 'fi' ],
              'it'  : [ 'vb', 'vj', 'vx', 'ef', 'ep', 'en', 'ec', 'xv', 'ed', 'nc', 'ad', 'px', 'pa', 'pc', 'nd', 'xn' ],
              'xa'  : [ 'xn', 'vj', 'ep', 'nc', 'ed' ],
              'xj'  : [ 'px', 'fi', 'pp', 'po', 'pd', 'vx', 'xj' ],
              'xv'  : [ 'px', 'fi', 'vx', 'pp', 'nc', 'px', 'se', 'pt', 'pa', 'po', 'sl', 'nd', 'vb', 'pc', 'xn', 'pd' ],
              'vb'  : [ 'fi', 'px', 'pt', 'sr', 'vb', 'sd', 'po', 'pa', 'sc', 'pa', 'nh', 'vx', 'pp', 'nc', 'nd', 'se', 'ps', 'pd', 'xn', 'vj', 'sf', 'na', 'sl', 'pc', 'pt', 'px', 'nr' ],
              'vj'  : [ 'px', 'pt', 'sr', 'sd', 'po', 'vx', 'fi', 'pp', 'nc', 'vb', 'se', 'pa', 'sc', 'nr', 'xj', 'ps' ],
              'vn'  : [ 'sr', 'px', 'nd', 'nr', 'pp', 'nc', 'xj', 'fi' ],
              'vx'  : [ 'fi', 'se', 'sr', 'pt', 'pc', 'px', 'pp', 'sl', 'sd', 'vx', 'ps', 'xn', 'nr', 'sf', 'nc' ],
              'vi'  : [ 'vb', 'fi' ],
              'sc'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'se'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'sf'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'sl'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'sr'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'sd'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'su'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'sy'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'so'  : [ 'ef', 'ed', 'ec', 'en', 'ex' ],
              'nh'  : [ 'ec' ],
              'ne'  : [ 'ed', 'ec', 'ex' ],
              'un'  : [ ],
              'xn'  : [ 'ex', 'ed', 'ec', 'ef', 'vx' ],
              'ini' : [ 'pa', 'pc', 'pd', 'po', 'pp', 'ps', 'pt', 'pv', 'px', 'pq', 'pm',
                        'ec', 'ed', 'ef', 'en', 'ep', 'ex', 'xn', 'xj', 'xv', 'xa' ]
            }


#
# getparams
#
def getparams(argv, progname):
    infile  = ''
    dicfile = ''
    lexfile = ''
    finfile = ''
    cutoff  = 10

    if len(argv) == 0 :
        print '%s -i <sejong.pos> -d <expand.dict> -l <korean.lexc> -c <cutoff=10> -o <final.dict>' % (progname, )
        sys.exit(2)
    try:
        opts, args = getopt.getopt(argv,"hi:d:l:c:o:",["ifile=","dfile=","lfile=","cutoff=","ofile="])
    except getopt.GetoptError:
        print '%s -i <sejong.pos> -d <expand.dict> -l <korean.lexc> -c <cutoff> -o <final.dict>' % (progname, )
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print '%s -i <sejong.pos> -d <expand.dict> -l <korean.lexc> -c <cutoff> -o <final.dict>' % (progname, )
            sys.exit()
        elif opt in ("-i", "--ifile"):
            infile  = arg
        elif opt in ("-d", "--dfile"):
            dicfile = arg
        elif opt in ("-l", "--lfile"):
            lexfile = arg
        elif opt in ("-c", "--cutoff"):
            cutoff  = arg
        elif opt in ("-o", "--ofile"):
            finfile = arg

    return ( infile, dicfile, lexfile, int (cutoff), finfile )

#
# dictionary를 만든다. 품사는 배열로 존재함.
#
def LoadDictionary(dicfile) :
    dicf   = codecs.open(dicfile, 'r', encoding='utf-8')
    inputs = dicf.read().splitlines()
    dic    = {}
    for sent in inputs : # 모든 한 줄 input에 대해서
        oneSent = sent.split('/') # '/'로 나눈다.
        length = len(oneSent)
        if length < 2 or length > 3 :
            print 'Error: Not accepted format: %s\n' % (sent, )
            sys.exit(2)
        lexeme = sent
        pos = oneSent[length-1]

        if lexeme == "쫒기/vb":
            print lexeme

        if pos in dic :
            dic[pos].append( lexeme )
        else :
            dic[pos] = [] # add new empty dictionary
            dic[pos].append( lexeme )
    dicf.close()
    return dic

#
# PosSentence읽어서 품사별로 분리한다.
#
def GetEojeol(eojeol) :
    morphemes = re.split('(?<=[a-z][a-z])\+(?!\/s)', eojeol) # split by +
    morphlist = [ re.split('/(?=[a-z][a-z])', morph) for morph in morphemes ] # split by /
    length = len(morphlist)
    if length > 1:
        for i in range(length-1, 0, -1): # reversed order
            morphlist.insert( i, []) # insert null array as a delimeter
    return morphlist

# aEojeol = [ ['임진왜란','nr'],    ['(','sl'], ['1592','nb'], ['년','nu'], [')','sr'], ['이전','nc'] ]
# aEojeol = [ ['들어서'  ,'vb'], ['어서','ec'],   ['야','px'], ['도','px'] ]
#           [ [               ], [], [       ], [],   [     ], [], [     ] ] 
#                     0          1       2      3        4     5      6
#
# 중간에 null array를 넣고 null array를 빼는 식으로 sequence의 
#
# merge pos sequence : 
#   1. p. \+ p. \+ p.
#   2. ep \+ ep
#   3. e[xcdf] \+ p. \+ p.
#
# particles = ('pa', 'pc', 'pd', 'po', 'ps', 'pt', 'pv', 'px', 'pq', 'pm') # excluding 'pp'
# endings   = ('ec', 'ed', 'ef', 'ex') # excluding 'en', 'ep'

#
# put connectability
#
def NewSplit(morphseq):
    for idx, morph in enumerate(morphseq):
        if idx >= len(morphseq) - 2 or morph == []: 
            continue # [] 이거나 마지막 어절일 경우 처리 안함.
        if morph[1] in particles:
            if morphseq[idx+2][1] in particles: # p. + p.
                del morphseq[idx+1] # delete delimeter
        elif morph[1] in endings:
            if morphseq[idx+2][1] in particles: # e[xcdf] + p.
                del morphseq[idx+1] # delete delimeter
        elif morph[1] == 'ep':
            if morphseq[idx+2][1] == 'ep': # ep + ep
                del morphseq[idx+1] # delete delimeter

#
# UpdateConnectMatrix(morphseq)
#
# conmtrx = {} # connect matrix
# aEojeol = [ ['들어서'  ,'vb'], ['어서','ec'], ['야','px'], [',','sc'] ]
#           [ [               ], [], [       ], [     ], [], [     ] ] 
#                     0          1       2         3     4      5
def UpdateConnectMatrix(morphseq, dic, conmtrx, tagpair):
    
    # put ini-first-tag
    pretag = 'ini'
    length = len(morphseq)
    curIdx = 0

    while curIdx < length :
        nxtIdx = curIdx
        while nxtIdx < length and morphseq[nxtIdx] != []:
            nxtIdx = nxtIdx + 1

        # curIdx .. nxtIdx - 1
        if curIdx + 1 == nxtIdx:
            nxttag = morphseq[curIdx][1] # ec
        else:
            nxttag = morphseq[curIdx][1] + morphseq[nxtIdx-1][1] # ecpx 
        if nxttag == 'epep':
            nxttag = 'ep'

        # delimiter is ::
        nxtmor = '::'.join([ '/'.join(m) for m in morphseq[curIdx:nxtIdx]]) 

        # tagpair
        tagseq = pretag + '+' + nxttag

        # put connect-matrix
        if pretag in conmtrx.keys():
            if nxttag not in conmtrx[pretag]:
                conmtrx[pretag].append(nxttag)
                tagpair[tagseq] = 1
            else:
                tagpair[tagseq] = tagpair[tagseq] + 1
        else:
            conmtrx[pretag] = []
            conmtrx[pretag].append(nxttag) 
            tagpair[tagseq] = 1

        # put extended word dictionary
        if len(nxttag) > 3: # if extended dictionary
            if nxttag in dic:
                if nxtmor not in dic[nxttag]:
                    dic[nxttag].append(nxtmor)
            else:
                dic[nxttag] = []
                dic[nxttag].append(nxtmor)
        elif nxttag == 'ep':
            if nxtmor not in dic[nxttag]:
                dic[nxttag].append(nxtmor)

        curIdx = nxtIdx + 1
        pretag = nxttag

    tagseq = pretag + '+fin'

    # put pretag - 'fin'
    if pretag in conmtrx.keys():
        if 'fin' not in conmtrx[pretag]:
            conmtrx[pretag].append('fin')
            tagpair[tagseq] = 1
        else:
            tagpair[tagseq] = tagpair[tagseq] + 1

    else:
        conmtrx[pretag] = []
        conmtrx[pretag].append('fin') 
        tagpair[tagseq] = 1


#
# MakeNewEntry(eojeolList)
#
def MakeNewEntry(eojeolList, dic, conmtrx, tagpair):
    for idx, eojeol in enumerate(eojeolList):
        aEojeol = GetEojeol(eojeol)                         # Get a single eojeol and analyze it
        NewSplit(aEojeol)                                   # Update Boundary
        UpdateConnectMatrix(aEojeol, dic, conmtrx, tagpair) # Update Connect-Matrix


#
# PrintEojeol
#
def PrintEojeol(aPosList) :
    for idx, value in enumerate(aPosList):
        if value != []:
            print '/'.join(value), 
        else:
            print 'BNDRY',
    print '\n'

#
# PrintConnectMatrix
#
def PrintConnectMatrix(conmtrx):
    for pretag in sorted(conmtrx):
        print pretag + " :",
        for nxttag in conmtrx[pretag]:
            print nxttag, 
        print '\n'

#
# WriteANewDictionary
#
def WriteANewDictionary(dic, outfile) :
    outf = codecs.open(outfile, 'w', encoding='utf-8')
    list = []

    for pos in dic: # for all pos
        for morph in dic[pos]: # for all morph
            list.append(morph)

    list.sort() # sort the list

    for entry in list:
        outf.write(entry + '\n')
    outf.close()


#
# WriteHanja
#
def WriteHanja(outf, dic, finf):
    hanlist = dic['nh'] # Get Array
    
    outf.write('               ') 
    for idx in range(len(hanlist)-1):
        finf.write(hanlist[idx][:-3] +'/nh\n')
        outf.write(hanlist[idx][:-3] + '|')
        if (idx+1) % 20 == 0:
            outf.write('\n               ') 
    outf.write(hanlist[-1][:-3] + ' ;\n\n')
    finf.write(hanlist[-1][:-3] +'/nh\n')
    outf.write('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n')

#
# WriteRoot
#
def WriteRoot(outf, conmtrx, tagpair, cutoff):
    outf.write('LEXICON Root\n')
    for nxttag in conmtrx['ini']:
        if nxttag[:2] not in disallows['ini'] and nxttag != 'un' :
            tagseq = 'ini+' + nxttag
            outf.write('       ' + nxttag + 'Lexicon ; ! ' + tagnames[nxttag[:2]])
            if len(nxttag) > 3:
                outf.write( '-' + tagnames[nxttag[-2:]] + '\n')
            else:
                outf.write('\n')
    outf.write('\n')

#
# WriteLexicon
#
def WriteLexicon(outf, dic, key, taglist, index, excindex, tagpair, cutoff, finf):
    outf.write('LEXICON ' + key + 'Lexicon ! ' + tagnames[key[:2]])
    if len(key) > 3:
        outf.write( '-' + tagnames[key[-2:]] + '\n')
    else:
        outf.write('\n')

    if key == 'nb': # 숫자
        outf.write('< Digit+ %/nb > nbNext ;\n')
    elif key == 'nh': # 한자
        outf.write('< Hanja+ %/nh > nhNext ;\n')
    elif key == 'ne': # 영어
        outf.write('< Alphabet+ %/ne > neNext ;\n')
    elif len(key) > 3: # e*p* , p*p*, 자/ecㄴ/px의/pd
        for lexeme in dic[key]:
            morphlist = lexeme.split('::')

            hasspecial = False
            for morph in morphlist:
                finf.write(morph+'\n')
                morph2 = morph.encode('utf-8')
                hits = index.query(morph2[:-3])
                if hits != []: 
                    hasspecial = True
            if hasspecial == False:
                lexeme = ''.join(morphlist)
                lexeme = lexeme.replace('ㄴ','%_ㄴ')
                lexeme = lexeme.replace('ㄹ','%_ㄹ')
                lexeme = lexeme.replace('ㅁ','%_ㅁ')
                lexeme = lexeme.replace('ㅂ','%_ㅂ')
                lexeme = lexeme.replace('ㅅ','%_ㅅ')
                lexeme = lexeme.replace('ㅇ','%_ㅇ')
                outf.write(lexeme + '\t' + key + 'Next ;\n')

    else: # normal case
        for lexeme in dic[key]:
            lexeme2 = lexeme.encode('utf-8') # 
            if excindex.query(lexeme2) != []:
                print 'exclude %s ' % (lexeme2, )
                continue
            if lexeme2.count('/') == 2 and key != 'sc' :
                hits = index.query(lexeme2[:-8])
            else:
                hits = index.query(lexeme2[:-3]) # find the special chars in lexeme
            if hits != []:
                if key in ( 'sc', 'se', 'sf', 'sl', 'sr', 'sd', 'su', 'sy', 'so'):
                    for (hit, ch) in reversed(hits):
                        (position, length) = hit
                        lexeme2 = lexeme2[:position] + '%' + lexeme2[position:]
                    outf.write(lexeme2 + '\t' + key + 'Next ;\n') 
                    finf.write(lexeme+'\n')
            else: 
                finf.write(lexeme+'\n')
                # 정상적인 한글에서 ㄴ,ㄹ,ㅁ,ㅂ,ㅅ,ㅇ으로 시작할 때 %_ 붙임 (어미, 조사) 
                if (lexeme[-2:] in ( 'ec', 'ed', 'ef', 'en', 'ex', 'pa', 'pc', 
                    'pd', 'po', 'ps', 'pt', 'pv', 'px', 'pq')) :
                    lexeme = lexeme.replace('ㄴ','%_ㄴ')
                    lexeme = lexeme.replace('ㄹ','%_ㄹ')
                    lexeme = lexeme.replace('ㅁ','%_ㅁ')
                    lexeme = lexeme.replace('ㅂ','%_ㅂ')
                    lexeme = lexeme.replace('ㅅ','%_ㅅ')
                    lexeme = lexeme.replace('ㅇ','%_ㅇ')
                outf.write(lexeme + '\t' + key + 'Next ;\n')

    outf.write('\n')
    outf.write('LEXICON ' + key + 'Next\n')
    nNext = 0
    maxtag = ''
    maxval = 0
    for nxttag in taglist:
        if nxttag[:2] not in disallows[key[-2:].encode('utf-8')] and nxttag != 'un' :

            if nxttag == 'fin' :
                tagseq = key[-2:] + '+' + nxttag
            else: tagseq = key[-2:] + '+' + nxttag[:2]

            try:
                tagpairfreq = tagpair[tagseq]
            except:
                tagseq = key + '+' + nxttag
                tagpairfreq = tagpair[tagseq]

            if tagpairfreq < cutoff :
                print 'cutoff %d : %s %d' % (cutoff, tagseq, tagpairfreq)
            else:
                outf.write('     ' + nxttag + 'Lexicon ;\n')
                nNext = nNext + 1

            if tagpairfreq > maxval:
                maxtag = nxttag
                maxval = tagpairfreq

    if nNext == 0:
        print 'cutoff value should be lower: %s-%s cannot be written' % (key, nxttag)
        outf.write('     ' + maxtag + 'Lexicon ;\n')

    outf.write('\n')

#
# WriteALexcFile(dic, conmtrx, outfile)
#
def WriteALexcFile(dic, conmtrx, lexfile, index, excindex, tagpair, cutoff, findic):
    outf = codecs.open(lexfile, 'w', encoding='utf-8')
    finf = codecs.open(findic, 'w', encoding='utf-8')

    outf.write(lexcHeader) # write a header file 
    WriteHanja(outf, dic, finf)
    WriteRoot(outf, conmtrx, tagpair, cutoff)
    for key in sorted(conmtrx):
        if key != 'ini' and key != 'fin' and key != 'un' :
            WriteLexicon(outf, dic, key, conmtrx[key], index, excindex, tagpair, cutoff, finf)

    outf.write('LEXICON finLexicon\n')
    outf.write('     # ;\n\n')
    outf.write('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n')
    outf.write('!!!!!!!! End of Document !!!!!!!!!\n')
    outf.write('!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n')
    outf.close()
    finf.close()


#
# Build multiple character matching
#
def MatchingMultipleChar(charset):
    index = esm.Index()
    for ch in charset:
        index.enter(ch)
    index.fix()
    return index

#
# Main
#
if __name__ == "__main__":
    infile, dicfile, lexfile, cutoff, findic = getparams(sys.argv[1:], sys.argv[0])
    dic = LoadDictionary(dicfile) # load dictionary - basic dictionary
    conmtrx = {} # connect matrix
    tagpair = {} # tag pair frequency

    index    = MatchingMultipleChar(specialchar)
    excindex = MatchingMultipleChar(excludechar.decode('utf-8'))

    # read pos file line by line and build connect-matrix and dictionary
    inf = codecs.open(infile, 'r', encoding='utf-8') # pos file

    for idx, line in enumerate(inf): # for all pos lines
        eojeolList = line.strip("\n").split(" ")
        MakeNewEntry(eojeolList, dic, conmtrx, tagpair)

        if idx % 10000 == 0:
            sys.stdout.write('.')
            sys.stdout.flush()
    inf.close()

    # write a lexc file
    WriteALexcFile(dic, conmtrx, lexfile, index, excindex, tagpair, cutoff, findic)

    # scan and write new dictionary
#    WriteANewDictionary(dic,lexfile)
    #PrintConnectMatrix(conmtrx)




