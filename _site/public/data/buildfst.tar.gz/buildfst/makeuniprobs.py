#!/usr/bin/env python
#-*- coding: utf-8 -*-

"""
   MakeLexc : Make Lexc file from tagged corpus

   Programmed by Sangho Lee
"""

import sys, getopt, codecs, re, esm, string
from math import log
reload (sys)
sys.setdefaultencoding('utf-8')

basictags = [ 'ini', 'ac', 'ad', 'ai', 'am', # 부사
              'di', 'dm', 'dn', 'du', # 관형사
              'ec', 'ed', 'ef', 'en', 'ep', 'ex', # 어미
              'it',                   # 감탄사
              'na', 'nc', 'nd', 'ni', 'nm', 'nn', 'np', 'nr', 'ns', 'nu', 'nb', # 체언
              'pa', 'pc', 'pd', 'po', 'pp', 'ps', 'pt', 'pv', 'px', 'pq', 'pm', # 조사
              'vb', 'vi', 'vj', 'vx', 'vn', # 용언
              'xa', 'xj', 'xn', 'xv',       # 접사
              'sc', 'se', 'sf', 'sl', 'sr', 'sd', 'su', 'sy', 'so', # 심벌
              'nh', 'ne', 'un' ] # 한자 (cHinese, English)

tagnames = { 'ac' : '접속부사'  , 'ad' : '부사', 'ai' : '의문부사', 'am' : '지시부사',
        'di' : '의문관형사', 'dm' : '지시관형사', 'dn' : '관형사', 'du' : '수관형사',
        'ec' : '연결어미', 'ed' : '관형사형전성어미', 'ef' : '어말어미', 
        'en' : '명사형전성어미', 'ep' : '선어말어미', 'ex' : '보조적연결어미',
        'it' : '감탄사',
        'na' : '동작성보통명사', 'nc' : '보통명사', 'nd' : '의존명사', 
        'ni' : '의문대명사', 'nm' : '지시대명사',
        'nn' : '수사', 'np' : '인칭대명사', 'nr' : '고유명사', 'ns' : '상태성보통명사',
        'nu' : '단위성의존명사', 'nb' : '숫자',
        'pa' : '부사격조사', 'pc' : '접속조사', 'pd' : '관형격조사', 'po' : '목적격조사',
        'pp' : '서술격조사', 'ps' : '주격조사', 'pt' : '주제격조사', 'pv' : '호격조사',
        'px' : '보조사', 'pq' : '인용격조사', 'pm' : '보격조사',
        'vb' : '동사', 'vi' : '의문형용사', 'vj' : '형용사', 'vx' : '보조용언', 'vn' : '부정지정사',
        'xa' : '부사파생접미사', 'xj' : '형용사파생접미사', 'xn' : '명사접미사',
        'xv' : '동사파생접미사',
        'sc' : '쉼표', 'se' : '줄임표', 'sf' : '마침표', 'sl': '여는따옴표', 'sr' : '닫는따옴표',
        'sd' : '이음표', 'su' : '단위', 'sy' : '화폐단위', 'so' : '기타기호',
        'nh' : '한자', 'ne' : '영어', 'un' : '분석불가' }


particles = ('pa', 'pc', 'pd', 'po', 'ps', 'pt', 'pv', 'px', 'pq', 'pm') # excluding 'pp'
endings   = ('ec', 'ed', 'ef', 'ex') # excluding 'en', 'ep'

specialchar = "!\"#$%&'()*+,-.0:;<=>?@[\\]^|/_`{}~"

###################################################################################

def WriteAttFile(att, wordfile):
    attfile = wordfile + ".att"
    symfile = wordfile + ".sym"

    # write attfile
    attf = codecs.open(attfile, 'w', encoding='utf-8')

    syms = []
    # Get Unique symbol
    for node in att:
        syms.append(node[2])
        attf.write('%d\t%d\t%s\t%s\t%f\n' % (node[0], node[1], node[2], node[2], node[3]))
    attf.write('0\t0.0\n')
    attf.close()

    print '# of used symbols : %d' % (len(syms), )

    symset = set(sorted(syms))
    print '# of Unique Symbols : %d' % (len(symset), )

    symf = codecs.open(symfile, 'w', encoding='utf-8')
    symf.write('<epsilon>   0\n')
    for idx, node in enumerate(symset):
        symf.write('%s\t%d\n' % (node, idx+1))
    symf.close()


###################################################################################

#
# 
#
def GetAtt(dic, word, nh, tagfreq, tranfreq, totnwords, totntags):

    # Scanning word and build isyms, osyms
    initstate = 0
    nstate    = 1
    att       = [] 

    for wordtag in dic:
        (wrd, tag) = wordtag
        freq = dic[wordtag][0]
        irrc = dic[wordtag][1]

        if tag in ('nh', 'nb', 'ne'):
            continue

        if freq == 0: freq = 0.5
        prob   = - log ( float (freq) / float (totnwords) )

        if wrd[0] == '_' and len(wrd) > 1 :
            prefix = '_'
            wrd = wrd[1:]
        else:
            prefix = ''

        length = len(wrd)
        if length == 1:
            att.append([initstate, nstate, prefix + wrd[0], 0.0])
            if irrc != '':
                nstate = nstate + 1
                att.append([nstate - 1, nstate, '/' + irrc, 0.0])
            att.append([nstate, initstate, '/' + tag, prob])
            nstate = nstate + 1
        else:
            att.append([initstate, nstate, prefix + wrd[0], 0.0])
            nstate = nstate + 1
            for idx in range(1, length):
                att.append([nstate - 1, nstate, wrd[idx], 0.0])
                nstate = nstate + 1
            if irrc != '':
                att.append([nstate - 1, nstate, '/' + irrc, 0.0])
                nstate = nstate + 1
            att.append([nstate - 1, initstate, '/' + tag, prob])

    # nh, nb, ne, tag 처리
    for hanja in nh: # hanja:hanja/0.0
        att.append([initstate, initstate, hanja, 0.0])
    for digit in string.digits:
        att.append([initstate, initstate, digit, 0.0])
    for alphabet in string.ascii_letters:
        att.append([initstate, initstate, alphabet, 0.0])

    # tag 정보, nh, nb, ne = 0
    att.append([initstate, initstate, '/nh', 0.0])
    att.append([initstate, initstate, '/nb', 0.0])
    att.append([initstate, initstate, '/ne', 0.0])

    # space
    att.append([initstate, initstate, "<space>", 0.0])

    return att


###################################################################################

#
# tranfreq = { 'na' : { 'nc' : 2, 'ni' : 3 } , ... }
# tagfreq  = { 'na' : 100, .... }
#
def InitTagFreq():
    tagfreq  = {}
    tranfreq = {}
    for tag in basictags :
        tagfreq[tag] = 0
        tranfreq[tag] = {}
        for totag in basictags :
            tranfreq[tag][totag] = 0
    return (tagfreq, tranfreq)

###################################################################################
#
# dictionary를 만든다. 품사는 배열로 존재함.
#
# wordfreq = { ('나', 'np') : [ 빈도, ''     ] , ... }
#          = { ('긋', 'vb') : [ 빈도, 'irrs' ] , ... }
#
# %_ㄴ %_ㄹ %_ㅁ %_ㅂ %_ㅅ %_ㅇ : 어미
# %_ㄴ/px %_ㄹ/po : 조사
#
def LoadDictionary(dicfile) :
    dicf   = codecs.open(dicfile, 'r', encoding='utf-8')
    inputs = dicf.read().splitlines()
    dic    = {}
    word   = {}
    nh     = {}
    for sent in inputs : # 모든 한 줄 input에 대해서
        if sent == "//sc" :
            dic[('/', 'sc')] = [ 0, '' ]
            word['/']        = 0
        else:
            oneSent = sent.split('/') # '/'로 나눈다.
            length = len(oneSent)
            if length < 2 or length > 3 :
                print 'Error: Not accepted format: %s\n' % (sent, )
                sys.exit(2)
            if length == 3 :
                irrcode = oneSent[1]
            else:
                irrcode = ''

            if oneSent[length-1] in ("ec", "ed", "ef", "en", "ep", "ex", "px", "po"):
                if oneSent[0][0] in ("ㄴ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ"):
                    oneSent[0] = "_" + oneSent[0]
            key = (oneSent[0], oneSent[length-1])
            if oneSent[length-1] not in ('nh', 'un', 'nb', 'ne') :
                dic[key] = [ 0, irrcode ]
                word[oneSent[0]] = 0  # simple word form
            elif oneSent[length-1] == 'nh':
                nh[oneSent[0]] = 1 # simple insertion

    dicf.close()

    return dic, word, nh


###################################################################################

#
# getparams
#
def getparams(argv, progname):
    infile   = ''
    dicfile  = ''
    wordfile = ''

    if len(argv) == 0 :
        print '%s -i <sejong.pos> -d <final.dict> -w <worduniprob> ' % (progname, )
        sys.exit(2)
    try:
        opts, args = getopt.getopt(argv,"hi:d:w:",["ifile=","dfile=","wfile="])
    except getopt.GetoptError:
        print '%s -i <sejong.pos> -d <final.dict> -w <worduniprob>' % (progname, )
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            print '%s -i <sejong.pos> -d <final.dict> -w <worduniprob>' % (progname, )
            sys.exit()
        elif opt in ("-i", "--ifile"):
            infile  = arg
        elif opt in ("-d", "--dfile"):
            dicfile = arg
        elif opt in ("-w", "--wfile"):
            wordfile = arg
    return ( infile, dicfile, wordfile )

####################################################################################

#
# PosSentence읽어서 품사별로 분리한다.
#
def GetEojeol(eojeol) :
    morphemes = re.split('(?<=[a-z][a-z])\+(?!\/s)', eojeol) # split by +
    morphlist = [ re.split('/(?=[a-z][a-z])', morph) for morph in morphemes ] # split by /
    return morphlist

#
# aEojeol = [ ['들어서'  ,'vb'], ['어서','ec'], ['야','px'], [',','sc'] ]
#
def CalculateFreq(eojeolList, dic, word, tagfreq, tranfreq, totnwords, totntags) :
    ptag = 'ini'
    for idx, eojeol in enumerate(eojeolList):
        morphlist = GetEojeol(eojeol)               # Get a single eojeol and analyze it
        for mIdx, morph in enumerate(morphlist):

            if morph[1] in ("ec", "ed", "ef", "en", "ep", "ex", "px", "po"):
                if morph[0][0] in ("ㄴ", "ㄹ", "ㅁ", "ㅂ", "ㅅ", "ㅇ"):
                    morph[0] = "_" + morph[0]

            wrd = morph[0].decode('utf-8')
            tag = morph[1].decode('utf-8')
#            print '-- %d %d %s %s' % (idx, mIdx, wrd, tag )

            if tag not in ('nh', 'nb', 'un', 'ne') :
                wordtag = (wrd, tag)
                if wordtag in dic:
                    word[wrd]       = word[wrd] + 1
                    dic[wordtag][0] = dic[wordtag][0] + 1 # 이르/irrL/vb 이르/irrl/vb 무시
#                    print ' %s %s : %d %d ' % (wrd, tag, word[wrd], dic[wordtag][0])
                    totnwords       = totnwords + 1

            tagfreq[tag]        = tagfreq[tag] + 1
            tranfreq[ptag][tag] = tranfreq[ptag][tag] + 1
#            print 'tag %s %s : %d %d ' % (ptag, tag, tagfreq[tag], tranfreq[ptag][tag])
            ptag                = tag
            totntags = totntags + 1

    return totnwords, totntags

####################################################################################

#
# Main
#
if __name__ == "__main__":
    infile, dicfile, wordfile = getparams(sys.argv[1:], sys.argv[0])
    dic, word, nh = LoadDictionary(dicfile) # load dictionary - basic dictionary

    totnwords = 0
    totntags  = 0
    tagfreq, tranfreq = InitTagFreq()

    # read pos file line by line and build connect-matrix and dictionary
    inf = codecs.open(infile, 'r', encoding='utf-8') # pos file

    for idx, line in enumerate(inf): # for all pos lines
        eojeolList = line.strip("\n").split(" ")
        (totnwords, totntags) = CalculateFreq(eojeolList, dic, word, tagfreq, tranfreq, totnwords, totntags)
        if idx % 10000 == 0:
            sys.stdout.write('.')
            sys.stdout.flush()
    inf.close()

#    print 'Total Words = %d' % (totnwords, )
#    print '나 freq = %d   나/np freq = %d' % ( word['나'.decode('utf-8')], dic[('나'.decode('utf-8'),'np')][0]) 

    att = GetAtt(dic, word, nh, tagfreq, tranfreq, totnwords, totntags)

    # write a lexc file
    WriteAttFile(att, wordfile)


